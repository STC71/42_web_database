Stickers Camagru (estilo apps de mensajería + 42)
================================================
00_42.png           → Icono 42 (primera posición)
01_chat_green.png   → Chat estilo WhatsApp
02_plane_blue.png   → Avión estilo Telegram
03_bubble_ios.png   → Burbuja estilo iMessage
04_messenger.png    → Chat estilo Messenger
05_signal.png       → Estilo Signal
06_discord.png      → Estilo Discord
07_slack.png        → Estilo Slack
08_instagram.png    → Estilo Instagram
09_sms.png          → SMS clásico
10_heart.png        → Corazón

Copia TODOS estos PNG a public/stickers/ de tu proyecto
(puedes eliminar los stickers geométricos antiguos si quieres).
