<?php

// Iniciar sesion
session_start();

// Cargar configuracion
require_once '../config/Config.php';
Config::load();

// Cargar clases core
require_once '../app/core/Database.php';
require_once '../app/core/Controller.php';
require_once '../app/core/Router.php';
require_once '../app/core/Mailer.php';
require_once '../app/core/Validator.php';
require_once '../app/core/Lang.php';

// Idioma (ES por defecto; ?lang=en|pt|de|fr|es)
Lang::init();

// Tras cambiar idioma, URL limpia (sin ?lang= permanente)
if (isset($_GET['lang']) && in_array($_GET['lang'], Lang::supported(), true)) {
    $path = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
    $qs = $_GET;
    unset($qs['lang']);
    $base = rtrim(getenv('APP_URL') ?: ($_ENV['APP_URL'] ?? 'http://localhost:8080'), '/');
    $target = $base . $path;
    if (!empty($qs)) {
        $target .= '?' . http_build_query($qs);
    }
    header('Location: ' . $target);
    exit;
}

// Inicializar router y enviar solicitud
$router = new Router();
$router->dispatch();
