<?php
/**
 * Lang.php — Internacionalización sencilla (ES / EN / PT / DE / FR)
 *
 * Uso en vistas:
 *   <?= Lang::get('nav.home') ?>
 *   <?= __('nav.home') ?>   // alias global
 *
 * Idioma por defecto: español (es).
 * Se guarda en sesión y en cookie "camagru_lang".
 */
class Lang {
    private static $lang = 'es';
    private static $strings = [];
    private static $supported = ['es', 'en', 'pt', 'de', 'fr'];

    /** Inicializar idioma (llamar tras session_start) */
    public static function init() {
        // 1) Cambio explícito por URL ?lang=xx
        if (isset($_GET['lang']) && in_array($_GET['lang'], self::$supported, true)) {
            self::$lang = $_GET['lang'];
            $_SESSION['lang'] = self::$lang;
            setcookie('camagru_lang', self::$lang, time() + 3600 * 24 * 365, '/');
        } elseif (!empty($_SESSION['lang']) && in_array($_SESSION['lang'], self::$supported, true)) {
            self::$lang = $_SESSION['lang'];
        } elseif (!empty($_COOKIE['camagru_lang']) && in_array($_COOKIE['camagru_lang'], self::$supported, true)) {
            self::$lang = $_COOKIE['camagru_lang'];
            $_SESSION['lang'] = self::$lang;
        } else {
            self::$lang = 'es'; // por defecto español
            $_SESSION['lang'] = 'es';
        }

        $file = __DIR__ . '/../../lang/' . self::$lang . '.php';
        if (is_file($file)) {
            self::$strings = require $file;
        } else {
            self::$strings = require __DIR__ . '/../../lang/es.php';
        }
    }

    public static function get($key, $fallback = null) {
        if (isset(self::$strings[$key])) {
            return self::$strings[$key];
        }
        // Fallback al español
        if (self::$lang !== 'es') {
            static $es = null;
            if ($es === null) {
                $esFile = __DIR__ . '/../../lang/es.php';
                $es = is_file($esFile) ? require $esFile : [];
            }
            if (isset($es[$key])) {
                return $es[$key];
            }
        }
        return $fallback !== null ? $fallback : $key;
    }

    public static function current() {
        return self::$lang;
    }

    public static function supported() {
        return self::$supported;
    }

    /** Metadatos de cada idioma (bandera emoji + nombre nativo) */
    public static function meta() {
        return [
            'es' => ['flag' => '🇪🇸', 'label' => 'Español'],
            'en' => ['flag' => '🇬🇧', 'label' => 'English'],
            'pt' => ['flag' => '🇵🇹', 'label' => 'Português'],
            'de' => ['flag' => '🇩🇪', 'label' => 'Deutsch'],
            'fr' => ['flag' => '🇫🇷', 'label' => 'Français'],
        ];
    }
}

/** Atajo global para traducir */
function __($key, $fallback = null) {
    return Lang::get($key, $fallback);
}
