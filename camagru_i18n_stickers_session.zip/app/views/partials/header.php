<?php
$appUrl = rtrim($_ENV['APP_URL'] ?? getenv('APP_URL') ?: 'http://localhost:8080', '/');
$currentLang = class_exists('Lang') ? Lang::current() : 'es';
$langMeta = class_exists('Lang') ? Lang::meta() : [];
$t = function ($key, $fb = null) {
    return class_exists('Lang') ? Lang::get($key, $fb) : ($fb ?? $key);
};
// URL actual sin el parámetro lang (para no acumular query strings)
$requestPath = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
?>
<!DOCTYPE html>
<html lang="<?php echo htmlspecialchars($currentLang); ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="Camagru - Photo sharing application with webcam and stickers">
    <title><?php echo htmlspecialchars($title ?? 'Camagru'); ?> - Camagru</title>
    <link rel="stylesheet" href="<?php echo $appUrl; ?>/css/style.css">
    <link rel="stylesheet" href="<?php echo $appUrl; ?>/css/i18n.css">
</head>
<body>
    <header class="site-header">
        <div class="container header-inner">
            <a href="<?php echo $appUrl; ?>/" class="logo">📸 Camagru</a>

            <nav class="main-nav" aria-label="Main">
                <ul>
                    <li><a href="<?php echo $appUrl; ?>/"><?php echo htmlspecialchars($t('nav.home')); ?></a></li>
                    <li><a href="<?php echo $appUrl; ?>/gallery"><?php echo htmlspecialchars($t('nav.gallery')); ?></a></li>
                    <?php if (isset($_SESSION['user_id'])): ?>
                        <li><a href="<?php echo $appUrl; ?>/editor"><?php echo htmlspecialchars($t('nav.editor')); ?></a></li>
                        <li><a href="<?php echo $appUrl; ?>/profile"><?php echo htmlspecialchars($t('nav.profile')); ?></a></li>
                        <li><a href="<?php echo $appUrl; ?>/settings"><?php echo htmlspecialchars($t('nav.settings')); ?></a></li>
                        <li><a href="<?php echo $appUrl; ?>/logout"><?php echo htmlspecialchars($t('nav.logout')); ?></a></li>
                    <?php else: ?>
                        <li><a href="<?php echo $appUrl; ?>/login"><?php echo htmlspecialchars($t('nav.login')); ?></a></li>
                        <li><a href="<?php echo $appUrl; ?>/register"><?php echo htmlspecialchars($t('nav.register')); ?></a></li>
                    <?php endif; ?>
                </ul>
            </nav>

            <div class="header-tools">
                <!-- Selector de idioma con banderas -->
                <div class="lang-switcher" title="<?php echo htmlspecialchars($t('lang.label')); ?>">
                    <?php foreach ($langMeta as $code => $meta): ?>
                        <?php
                        $sep = (strpos($requestPath, '?') !== false) ? '&' : '?';
                        // Preferimos ?lang= en la ruta actual
                        $href = $appUrl . $requestPath . '?lang=' . urlencode($code);
                        $active = ($code === $currentLang) ? ' active' : '';
                        ?>
                        <a class="lang-flag<?php echo $active; ?>"
                           href="<?php echo htmlspecialchars($href); ?>"
                           hreflang="<?php echo $code; ?>"
                           title="<?php echo htmlspecialchars($meta['label']); ?>"
                           aria-label="<?php echo htmlspecialchars($meta['label']); ?>">
                            <span class="flag-emoji" aria-hidden="true"><?php echo $meta['flag']; ?></span>
                        </a>
                    <?php endforeach; ?>
                </div>

                <!-- Usuario de la sesión actual (siempre visible) -->
                <div class="session-badge" aria-live="polite">
                    <?php if (!empty($_SESSION['user_id']) && !empty($_SESSION['username'])): ?>
                        <span class="session-dot online" aria-hidden="true"></span>
                        <span class="session-label"><?php echo htmlspecialchars($t('nav.logged_as')); ?></span>
                        <strong class="session-user"><?php echo htmlspecialchars($_SESSION['username']); ?></strong>
                    <?php else: ?>
                        <span class="session-dot offline" aria-hidden="true"></span>
                        <span class="session-label"><?php echo htmlspecialchars($t('nav.session')); ?>:</span>
                        <strong class="session-user guest"><?php echo htmlspecialchars($t('nav.guest')); ?></strong>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </header>

    <main>
        <div class="container">
            <?php if (isset($_SESSION['flash_success'])): ?>
                <div class="flash flash-success">
                    <?php echo $_SESSION['flash_success']; unset($_SESSION['flash_success']); ?>
                </div>
            <?php endif; ?>

            <?php if (isset($_SESSION['flash_error'])): ?>
                <div class="flash flash-error">
                    <?php echo $_SESSION['flash_error']; unset($_SESSION['flash_error']); ?>
                </div>
            <?php endif; ?>
